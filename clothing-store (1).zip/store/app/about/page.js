'use client';
import { useStore } from '@/lib/store';
export default function About() { const { settings: s } = useStore(); return <div className="wrap max-w-2xl py-14"><h1 className="h2 mb-6">من نحن</h1><p className="whitespace-pre-line leading-9">{s.about || 'عدّل هذا النص من لوحة التحكم ← الإعدادات.'}</p></div> }
