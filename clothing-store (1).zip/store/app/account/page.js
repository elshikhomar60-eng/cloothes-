'use client';
import { useEffect, useState } from 'react'; import { supabase, money } from '@/lib/supabase';
const ST = { new: 'جديد', processing: 'قيد التجهيز', shipped: 'تم الشحن', delivered: 'تم التسليم', cancelled: 'ملغي' };
export default function Account() {
  const [u, setU] = useState(undefined), [mode, setMode] = useState('in'), [em, setEm] = useState(''), [pw, setPw] = useState(''), [msg, setMsg] = useState(''), [orders, setOrders] = useState([]);
  useEffect(() => { supabase.auth.getUser().then(({ data }) => setU(data.user || null)); const { data: s } = supabase.auth.onAuthStateChange((_, ses) => setU(ses?.user || null)); return () => s.subscription.unsubscribe() }, []);
  useEffect(() => { if (u) supabase.from('orders').select('*, order_items(*)').eq('user_id', u.id).order('created_at', { ascending: false }).then(({ data }) => setOrders(data || [])) }, [u]);
  const submit = async e => {
    e.preventDefault(); setMsg('');
    if (mode === 'up') { const { data, error } = await supabase.auth.signUp({ email: em, password: pw }); if (error) return setMsg(error.message); if (!data.session) setMsg('تحقق من بريدك لتأكيد الحساب') }
    else { const { error } = await supabase.auth.signInWithPassword({ email: em, password: pw }); if (error) setMsg('بيانات الدخول غير صحيحة') }
  };
  if (u === undefined) return <p className="py-32 text-center">جارٍ التحميل…</p>;
  if (!u) return <div className="wrap max-w-sm py-12"><h1 className="h2 mb-6">حسابي</h1>
    <form onSubmit={submit} className="grid gap-3"><input required type="email" dir="ltr" className="input text-start" placeholder="البريد الإلكتروني" value={em} onChange={e => setEm(e.target.value)} /><input required type="password" minLength={6} dir="ltr" className="input text-start" placeholder="كلمة المرور" value={pw} onChange={e => setPw(e.target.value)} />
      {msg && <p className="text-crimson" role="alert">{msg}</p>}<button className="btn">{mode === 'in' ? 'تسجيل الدخول' : 'إنشاء حساب'}</button>
      <button type="button" className="underline" onClick={() => setMode(mode === 'in' ? 'up' : 'in')}>{mode === 'in' ? 'إنشاء حساب' : 'تسجيل الدخول'}</button></form>
    <p className="mt-6 text-sm text-ink/60"><a href="/track" className="underline">متابعة طلب بدون حساب</a></p></div>;
  return <div className="wrap max-w-2xl py-12"><div className="mb-6 flex items-center justify-between"><h1 className="h2">طلباتي</h1><button className="btn-out" onClick={() => supabase.auth.signOut()}>تسجيل الخروج</button></div>
    {!orders.length ? <p className="text-ink/60">لا توجد طلبات بعد.</p> : <div className="grid gap-3">{orders.map(o => <div key={o.id} className="card"><div className="flex justify-between font-bold"><span>طلب رقم {o.number}</span><span>{ST[o.status]}</span></div>
      <ul className="mt-2 text-sm">{o.order_items.map(i => <li key={i.id}>{i.name} — {i.size} / {i.color} × {i.qty}</li>)}</ul><div className="mt-2 font-bold">الإجمالي: {money(o.total)}</div></div>)}</div>}</div>;
}
