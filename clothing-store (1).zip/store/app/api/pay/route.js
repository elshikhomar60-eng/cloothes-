import { createClient } from '@supabase/supabase-js';
const P = 'https://accept.paymob.com/api';
const post = (u, b) => fetch(P + u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json());
export async function POST(req) {
  const { number, phone } = await req.json();
  const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
  const { data: o } = await db.from('orders').select('*').eq('number', number).eq('phone', phone).eq('payment', 'card').eq('paid', false).maybeSingle();
  if (!o) return Response.json({ error: 'not_found' }, { status: 404 });
  const { token } = await post('/auth/tokens', { api_key: process.env.PAYMOB_API_KEY });
  const cents = Math.round(o.total * 100);
  const ord = await post('/ecommerce/orders', { auth_token: token, delivery_needed: false, amount_cents: cents, currency: 'EGP', merchant_order_id: `${o.number}-${Date.now()}`, items: [] });
  const [first, ...rest] = (o.name || 'Customer').split(' ');
  const key = await post('/acceptance/payment_keys', { auth_token: token, amount_cents: cents, expiration: 3600, order_id: ord.id, currency: 'EGP', integration_id: +process.env.PAYMOB_INTEGRATION_ID,
    billing_data: { first_name: first, last_name: rest.join(' ') || 'NA', email: 'customer@example.com', phone_number: o.phone, apartment: 'NA', floor: 'NA', street: (o.address || 'NA').slice(0, 100), building: 'NA', shipping_method: 'NA', postal_code: 'NA', city: 'NA', country: 'EG', state: 'NA' } });
  if (!key.token) return Response.json({ error: 'paymob' }, { status: 502 });
  return Response.json({ url: `${P}/acceptance/iframes/${process.env.PAYMOB_IFRAME_ID}?payment_token=${key.token}` });
}
