import crypto from 'crypto'; import { createClient } from '@supabase/supabase-js';
const K = ['amount_cents', 'created_at', 'currency', 'error_occured', 'has_parent_transaction', 'id', 'integration_id', 'is_3d_secure', 'is_auth', 'is_capture', 'is_refunded', 'is_standalone_payment', 'is_voided', 'order.id', 'owner', 'pending', 'source_data.pan', 'source_data.sub_type', 'source_data.type', 'success'];
const get = (o, p) => p.split('.').reduce((a, k) => a?.[k], o);
export async function POST(req) {
  const hmac = new URL(req.url).searchParams.get('hmac') || '', body = await req.json(), o = body.obj || {};
  const calc = crypto.createHmac('sha512', process.env.PAYMOB_HMAC).update(K.map(k => get(o, k)).join('')).digest('hex');
  if (calc.length !== hmac.length || !crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(hmac))) return new Response('bad signature', { status: 401 });
  if (o.success === true && o.pending === false) {
    const num = +String(o.order?.merchant_order_id).split('-')[0];
    await createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY).from('orders').update({ paid: true }).eq('number', num);
  }
  return new Response('ok');
}
