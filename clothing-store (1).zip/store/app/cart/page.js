'use client';
import { useEffect, useState } from 'react'; import Link from 'next/link'; import { Trash2 } from 'lucide-react';
import { supabase, money } from '@/lib/supabase'; import { useStore } from '@/lib/store';
export default function Cart() {
  const { cart, upd, del } = useStore(), [code, setCode] = useState(''), [applied, setApplied] = useState(''), [quote, setQuote] = useState(null), [err, setErr] = useState('');
  const items = cart.map(({ product_id, size, color, qty }) => ({ product_id, size, color, qty })), key = JSON.stringify(items);
  const run = async c => {
    if (!cart.length) return setQuote(null);
    const { data, error } = await supabase.rpc('quote_order', { items, p_coupon: c || null });
    if (error) { setQuote(null); setErr(error.message.includes('coupon') ? 'الكوبون غير صالح أو منتهي' : error.message.includes('out_of_stock') ? 'إحدى القطع غير متوفرة بالكمية المطلوبة' : 'تعذّر حساب الطلب'); if (c) { setApplied(''); sessionStorage.removeItem('coupon') } return }
    setErr(''); setQuote(data); setApplied(c || ''); if (c) sessionStorage.setItem('coupon', c); else sessionStorage.removeItem('coupon');
  };
  useEffect(() => { run(applied) }, [key]);
  if (!cart.length) return <div className="py-32 text-center"><p className="mb-6 text-xl">سلتك فارغة</p><Link href="/shop" className="btn">ابدأ التسوق</Link></div>;
  return <div className="wrap grid gap-10 py-10 md:grid-cols-[1fr_380px]">
    <div><h1 className="h2 mb-6">سلة التسوق</h1><div className="grid gap-3">{cart.map((x, i) => <div key={i} className="card flex gap-4">
      <img src={x.image} alt="" className="h-28 w-24 object-cover" />
      <div className="flex-1"><div className="font-semibold">{x.name}</div><div className="font-bold text-green">{money(x.price)}</div>
        <div className="mt-2 flex flex-wrap gap-2"><select className="input !w-auto !py-1" value={x.size} onChange={e => upd(i, { size: e.target.value })}>{x.sizes.map(s => <option key={s}>{s}</option>)}</select>
          <select className="input !w-auto !py-1" value={x.color} onChange={e => upd(i, { color: e.target.value })}>{x.colors.map(s => <option key={s}>{s}</option>)}</select>
          <div className="flex items-center border border-ink/25"><button className="px-3" onClick={() => upd(i, { qty: Math.max(1, x.qty - 1) })}>−</button><span className="w-8 text-center">{x.qty}</span><button className="px-3" onClick={() => upd(i, { qty: x.qty + 1 })}>+</button></div></div></div>
      <button aria-label="حذف" onClick={() => del(i)} className="self-start text-crimson"><Trash2 size={20} /></button></div>)}</div></div>
    <aside className="card h-fit"><h2 className="mb-4 text-xl font-bold">ملخص الطلب</h2>
      <div className="mb-4 flex gap-2"><input className="input" placeholder="كود الخصم" value={code} onChange={e => setCode(e.target.value)} /><button className="btn-out" onClick={() => run(code.trim())}>تطبيق</button></div>
      {err && <p className="mb-3 text-sm text-crimson" role="alert">{err}</p>}
      {quote && <dl className="grid gap-2"><div className="flex justify-between"><dt>المجموع</dt><dd>{money(quote.subtotal)}</dd></div>
        {quote.discount > 0 && <div className="flex justify-between text-green"><dt>الخصم ({applied})</dt><dd>-{money(quote.discount)}</dd></div>}
        <div className="flex justify-between"><dt>الشحن</dt><dd>{quote.shipping ? money(quote.shipping) : 'مجاني'}</dd></div>
        <div className="mt-2 flex justify-between border-t border-mist pt-3 text-xl font-bold"><dt>الإجمالي</dt><dd>{money(quote.total)}</dd></div></dl>}
      <Link href="/checkout" className={`btn mt-5 w-full ${quote ? '' : 'pointer-events-none opacity-40'}`}>إتمام الطلب</Link></aside></div>;
}
