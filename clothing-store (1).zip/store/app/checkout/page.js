'use client';
import { useEffect, useState } from 'react'; import Link from 'next/link';
import { supabase, money } from '@/lib/supabase'; import { useStore } from '@/lib/store';
export default function Checkout() {
  const { cart, clear } = useStore(), [quote, setQuote] = useState(null), [done, setDone] = useState(null), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const [f, setF] = useState({ name: '', phone: '', address: '', payment: 'cod' }), set = k => e => setF({ ...f, [k]: e.target.value });
  const items = cart.map(({ product_id, size, color, qty }) => ({ product_id, size, color, qty })), coupon = typeof window !== 'undefined' ? sessionStorage.getItem('coupon') : null;
  useEffect(() => { if (cart.length) supabase.rpc('quote_order', { items, p_coupon: coupon }).then(({ data }) => setQuote(data)) }, [cart.length]);
  const submit = async e => {
    e.preventDefault(); setBusy(true); setErr('');
    const { data, error } = await supabase.rpc('place_order', { p_name: f.name, p_phone: f.phone, p_address: f.address, p_payment: f.payment, items, p_coupon: coupon });
    setBusy(false); if (error) return setErr(error.message.includes('out_of_stock') ? 'نفدت كمية إحدى القطع، راجع السلة.' : 'تعذّر إتمام الطلب، تأكد من بياناتك وحاول مجددًا.');
    sessionStorage.removeItem('coupon'); clear();
    if (f.payment === 'card') { try { const r = await fetch('/api/pay', { method: 'POST', body: JSON.stringify({ number: data, phone: f.phone }) }); const j = await r.json(); if (j.url) return (window.location.href = j.url) } catch {} setErr('تعذّر فتح صفحة الدفع، سنتواصل معك لإتمام الدفع.') }
    setDone(data);
  };
  if (done) return <div className="py-28 text-center"><h1 className="h2">تم استلام طلبك</h1><p className="mt-4 text-xl">رقم الطلب: <b>{done}</b></p><p className="mt-2 text-ink/70">احتفظ بالرقم ورقم هاتفك لمتابعة الطلب.</p><Link href={`/track?n=${done}`} className="btn mt-8">متابعة الطلب</Link></div>;
  if (!cart.length) return <div className="py-32 text-center"><Link href="/shop" className="btn">سلتك فارغة، تسوّق الآن</Link></div>;
  return <form onSubmit={submit} className="wrap grid gap-10 py-10 md:grid-cols-[1fr_380px]">
    <div className="grid gap-4"><h1 className="h2">إتمام الطلب</h1>
      <label><span className="lbl">الاسم</span><input required className="input" value={f.name} onChange={set('name')} autoComplete="name" /></label>
      <label><span className="lbl">رقم الهاتف</span><input required type="tel" dir="ltr" className="input text-start" value={f.phone} onChange={set('phone')} autoComplete="tel" /></label>
      <label><span className="lbl">العنوان بالتفصيل</span><textarea required rows={3} className="input" value={f.address} onChange={set('address')} /></label>
      <fieldset><legend className="lbl">طريقة الدفع</legend>{[['cod', 'الدفع عند الاستلام'], ['card', 'بطاقة / محفظة (دفع إلكتروني)'], ['transfer', 'تحويل بنكي / محفظة إلكترونية (سنتواصل معك)']].map(([v, t]) => <label key={v} className="mb-2 flex items-center gap-3 border border-ink/25 bg-white p-3"><input type="radio" name="pay" checked={f.payment === v} onChange={() => setF({ ...f, payment: v })} />{t}</label>)}</fieldset></div>
    <aside className="card h-fit"><h2 className="mb-3 text-xl font-bold">مراجعة الطلب</h2>
      {cart.map((x, i) => <div key={i} className="flex justify-between border-b border-mist py-2 text-sm"><span>{x.name} — {x.size} / {x.color} × {x.qty}</span><span>{money(x.price * x.qty)}</span></div>)}
      {quote && <dl className="mt-3 grid gap-1"><div className="flex justify-between"><dt>الخصم</dt><dd>-{money(quote.discount)}</dd></div><div className="flex justify-between"><dt>الشحن</dt><dd>{quote.shipping ? money(quote.shipping) : 'مجاني'}</dd></div><div className="flex justify-between text-xl font-bold"><dt>الإجمالي</dt><dd>{money(quote.total)}</dd></div></dl>}
      {err && <p className="mt-3 text-crimson" role="alert">{err}</p>}
      <button className="btn mt-5 w-full" disabled={busy}>{busy ? 'جارٍ الإرسال…' : 'تأكيد الطلب'}</button></aside></form>;
}
