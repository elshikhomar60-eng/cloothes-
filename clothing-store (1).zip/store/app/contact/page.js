'use client';
import { useStore } from '@/lib/store';
export default function Contact() { const { settings: s } = useStore(); return <div className="wrap max-w-2xl py-14"><h1 className="h2 mb-6">اتصل بنا</h1><div className="grid gap-3 text-lg">{s.phone && <a dir="ltr" className="text-start" href={`tel:${s.phone}`}>{s.phone}</a>}{s.whatsapp && <a className="text-green underline" href={`https://wa.me/${s.whatsapp}`}>راسلنا على واتساب</a>}{s.address && <p>{s.address}</p>}</div></div> }
