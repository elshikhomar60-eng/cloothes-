'use client';
import { useEffect, useState } from 'react'; import Link from 'next/link';
import { supabase } from '@/lib/supabase'; import { useStore } from '@/lib/store'; import ProductCard from '@/components/ProductCard';
function Row({ title, items, href }) {
  if (!items.length) return null;
  return <section className="wrap mt-20"><div className="mb-6 flex items-end justify-between"><h2 className="h2">{title}</h2>{href && <Link href={href} className="text-brass2 underline underline-offset-4">عرض الكل</Link>}</div>
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">{items.slice(0, 8).map(p => <ProductCard key={p.id} p={p} />)}</div></section>;
}
export default function Home() {
  const { cats, settings } = useStore(), [banners, setB] = useState([]), [prods, setP] = useState([]), [i, setI] = useState(0);
  useEffect(() => {
    supabase.from('banners').select('*').eq('visible', true).order('sort').then(({ data }) => setB(data || []));
    supabase.from('products').select('*').eq('visible', true).order('created_at', { ascending: false }).limit(80).then(({ data }) => setP(data || []));
  }, []);
  useEffect(() => { if (banners.length < 2) return; const t = setInterval(() => setI(x => (x + 1) % banners.length), 6000); return () => clearInterval(t) }, [banners]);
  const b = banners[i], featured = prods.filter(p => p.featured);
  return <>
    <section className="relative grid min-h-[78vh] items-end overflow-hidden bg-green">
      {b?.image && <img key={b.id} src={b.image} alt="" className="absolute inset-0 h-full w-full object-cover" />}
      <div className="absolute inset-0 bg-gradient-to-t from-green/90 via-green/30 to-transparent" />
      <div className="hero-in wrap relative pb-16 pt-40 text-stone" key={b?.id || 'x'}>
        <h1 className="max-w-3xl font-display text-5xl font-bold leading-tight md:text-7xl">{b?.title || settings.store_name || 'ATELIER'}</h1>
        <p className="mt-4 max-w-xl text-lg text-stone/80">{b?.subtitle || settings.tagline}</p>
        <Link href={b?.link || '/shop'} className="btn mt-8 !bg-brass !text-ink hover:!bg-stone">تسوّق الآن</Link>
      </div>
      {banners.length > 1 && <div className="absolute bottom-5 end-5 flex gap-2">{banners.map((_, n) => <button key={n} aria-label={`بانر ${n + 1}`} onClick={() => setI(n)} className={`h-1.5 w-8 ${n === i ? 'bg-brass' : 'bg-stone/40'}`} />)}</div>}
    </section>
    {cats.length > 0 && <section className="wrap mt-20"><h2 className="h2 mb-6">تسوّق حسب القسم</h2>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{cats.map(c => <Link key={c.id} href={`/shop?c=${c.slug}`} className="group relative block aspect-[4/5] overflow-hidden bg-mist">
        {c.image && <img src={c.image} alt="" loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />}
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" /><span className="absolute bottom-4 start-4 font-display text-2xl font-bold text-stone">{c.name}</span></Link>)}</div></section>}
    <Row title="مختارات لك" items={featured} href="/shop" />
    <Row title="وصل حديثًا" items={prods} href="/shop" />
    <Row title="الأكثر مبيعًا" items={prods.filter(p => p.best_seller)} href="/shop" />
    <Row title="عروض وخصومات" items={prods.filter(p => p.sale_price)} href="/shop?sale=1" />
    {!prods.length && <p className="wrap py-24 text-center text-ink/60">لا توجد منتجات بعد. أضف أول منتج من لوحة التحكم /admin</p>}
  </>;
}
