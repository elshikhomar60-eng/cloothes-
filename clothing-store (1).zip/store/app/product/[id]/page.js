'use client';
import { useEffect, useState } from 'react'; import { useParams, useRouter } from 'next/navigation'; import { Heart, X } from 'lucide-react';
import { supabase, money } from '@/lib/supabase'; import { useStore } from '@/lib/store'; import ProductCard from '@/components/ProductCard';
export default function Product() {
  const { id } = useParams(), r = useRouter(), { add, favs, toggleFav } = useStore();
  const [p, setP] = useState(), [sim, setSim] = useState([]), [img, setImg] = useState(0), [zoom, setZoom] = useState(false), [size, setSize] = useState(), [color, setColor] = useState(), [qty, setQty] = useState(1), [msg, setMsg] = useState('');
  useEffect(() => {
    supabase.from('products').select('*, stock(*)').eq('id', id).eq('visible', true).maybeSingle().then(({ data }) => {
      setP(data || false); if (!data) return; setColor(data.colors[0]?.name);
      if (data.category_id) supabase.from('products').select('*').eq('category_id', data.category_id).neq('id', id).eq('visible', true).limit(4).then(({ data: d }) => setSim(d || []));
    });
  }, [id]);
  if (p === undefined) return <p className="py-32 text-center">جارٍ التحميل…</p>;
  if (p === false) return <p className="py-32 text-center">المنتج غير موجود.</p>;
  const q = (s, c) => p.stock.find(x => x.size === s && x.color === c)?.qty || 0, max = size ? q(size, color) : 0;
  const colorOk = c => p.sizes.some(s => q(s, c) > 0);
  const item = () => ({ product_id: p.id, name: p.name, image: p.images[0], price: p.sale_price ?? p.price, size, color, qty, sizes: p.sizes, colors: p.colors.map(c => c.name) });
  const go = (now) => { if (!size) return setMsg('اختر المقاس أولًا'); if (qty > max) return setMsg('الكمية المطلوبة غير متوفرة'); add(item()); now ? r.push('/checkout') : setMsg('تمت الإضافة إلى السلة ✓') };
  return <div className="wrap py-10"><div className="grid gap-10 md:grid-cols-2">
    <div><button onClick={() => setZoom(true)} className="block aspect-[3/4] w-full cursor-zoom-in overflow-hidden bg-mist">{p.images[img] && <img src={p.images[img]} alt={p.name} className="h-full w-full object-cover" />}</button>
      <div className="mt-3 flex gap-2 overflow-x-auto">{p.images.map((u, n) => <button key={n} onClick={() => setImg(n)} className={`h-24 w-20 shrink-0 border-2 ${n === img ? 'border-brass' : 'border-transparent'}`}><img src={u} alt="" className="h-full w-full object-cover" /></button>)}</div></div>
    <div><h1 className="font-display text-4xl font-bold">{p.name}</h1>
      <div className="mt-3 flex items-baseline gap-3 text-2xl"><b className="text-green">{money(p.sale_price ?? p.price)}</b>{p.sale_price && <s className="text-base text-ink/50">{money(p.price)}</s>}</div>
      <p className="mt-5 whitespace-pre-line leading-8 text-ink/80">{p.description}</p>
      <div className="mt-6"><div className="lbl">اللون: {color}</div><div className="flex gap-2">{p.colors.map(c => <button key={c.name} title={c.name} disabled={!colorOk(c.name)} onClick={() => { setColor(c.name); setSize(undefined); setQty(1) }} className={`h-9 w-9 rounded-full border-2 disabled:opacity-30 ${color === c.name ? 'border-brass ring-2 ring-brass/40' : 'border-ink/20'}`} style={{ background: c.hex }} />)}</div></div>
      <div className="mt-6"><div className="lbl">المقاس</div><div className="flex flex-wrap gap-2">{p.sizes.map(s => <button key={s} disabled={q(s, color) < 1} onClick={() => { setSize(s); setQty(1) }} className={`min-w-14 border px-4 py-2 disabled:cursor-not-allowed disabled:text-ink/30 disabled:line-through ${size === s ? 'border-green bg-green text-stone' : 'border-ink/25 hover:border-brass'}`}>{s}</button>)}</div>
        {size && <p className="mt-2 text-sm text-ink/60">{max <= 5 ? `متبقي ${max} فقط` : 'متوفر'}</p>}</div>
      <div className="mt-6 flex items-center gap-3"><div className="lbl !mb-0">الكمية</div><div className="flex items-center border border-ink/25"><button className="px-4 py-2" onClick={() => setQty(Math.max(1, qty - 1))}>−</button><span className="w-10 text-center">{qty}</span><button className="px-4 py-2" onClick={() => setQty(Math.min(max || 1, qty + 1))}>+</button></div></div>
      <div className="mt-8 flex flex-wrap gap-3"><button className="btn flex-1" onClick={() => go(false)}>أضف إلى السلة</button><button className="btn-out flex-1" onClick={() => go(true)}>اشترِ الآن</button>
        <button aria-label="مفضلة" onClick={() => toggleFav(p.id)} className="btn-out !px-4"><Heart size={20} fill={favs.includes(p.id) ? '#A6192E' : 'none'} /></button></div>
      {msg && <p className="mt-3 font-medium text-green" role="status">{msg}</p>}</div></div>
    {sim.length > 0 && <section className="mt-20"><h2 className="h2 mb-6">منتجات مشابهة</h2><div className="grid grid-cols-2 gap-4 md:grid-cols-4">{sim.map(x => <ProductCard key={x.id} p={x} />)}</div></section>}
    {zoom && <div className="fixed inset-0 z-50 grid place-items-center bg-ink/90 p-4" onClick={() => setZoom(false)}><button className="absolute end-4 top-4 text-stone" aria-label="إغلاق"><X size={32} /></button><img src={p.images[img]} alt="" className="max-h-full max-w-full object-contain" /></div>}
  </div>;
}
