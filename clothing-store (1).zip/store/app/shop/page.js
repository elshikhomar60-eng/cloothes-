'use client';
import { Suspense, useEffect, useState } from 'react'; import Link from 'next/link'; import { useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabase'; import { useStore } from '@/lib/store'; import ProductCard from '@/components/ProductCard';
function Shop() {
  const sp = useSearchParams(), { cats } = useStore(), c = sp.get('c'), q = sp.get('q'), sale = sp.get('sale');
  const [items, setItems] = useState(null), [sort, setSort] = useState('new');
  useEffect(() => {
    if (c && !cats.length) return;
    let req = supabase.from('products').select('*').eq('visible', true);
    const cat = cats.find(x => x.slug === c); if (c && cat) req = req.eq('category_id', cat.id);
    if (q) req = req.ilike('name', `%${q}%`); if (sale) req = req.not('sale_price', 'is', null);
    req = sort === 'new' ? req.order('created_at', { ascending: false }) : req.order('price', { ascending: sort === 'asc' });
    req.then(({ data }) => setItems(data || []));
  }, [c, q, sale, sort, cats]);
  const chip = (on) => `px-4 py-2 border ${on ? 'bg-green text-stone border-green' : 'border-ink/25 hover:border-brass'}`;
  return <div className="wrap py-10">
    <h1 className="h2 mb-6">{q ? `نتائج: ${q}` : sale ? 'العروض' : cats.find(x => x.slug === c)?.name || 'كل المنتجات'}</h1>
    <div className="mb-8 flex flex-wrap items-center gap-2">
      <Link href="/shop" className={chip(!c && !sale && !q)}>الكل</Link>
      {cats.map(x => <Link key={x.id} href={`/shop?c=${x.slug}`} className={chip(c === x.slug)}>{x.name}</Link>)}
      <select value={sort} onChange={e => setSort(e.target.value)} className="input ms-auto !w-auto"><option value="new">الأحدث</option><option value="asc">السعر: الأقل</option><option value="desc">السعر: الأعلى</option></select></div>
    {items === null ? <p className="py-20 text-center">جارٍ التحميل…</p> : !items.length ? <p className="py-20 text-center text-ink/60">لا توجد منتجات مطابقة.</p> :
      <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">{items.map(p => <ProductCard key={p.id} p={p} />)}</div>}
  </div>;
}
export default function Page() { return <Suspense><Shop /></Suspense> }
