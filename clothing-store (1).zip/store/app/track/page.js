'use client';
import { Suspense, useState } from 'react'; import { useSearchParams } from 'next/navigation';
import { supabase, money } from '@/lib/supabase';
const ST = { new: 'جديد', processing: 'قيد التجهيز', shipped: 'تم الشحن', delivered: 'تم التسليم', cancelled: 'ملغي' }, ORDER = ['new', 'processing', 'shipped', 'delivered'];
function Track() {
  const sp = useSearchParams(), [n, setN] = useState(sp.get('n') || ''), [ph, setPh] = useState(''), [o, setO] = useState(), [busy, setBusy] = useState(false);
  const go = async e => { e.preventDefault(); setBusy(true); const { data } = await supabase.rpc('track_order', { p_number: +n, p_phone: ph.trim() }); setO(data || false); setBusy(false) };
  return <div className="wrap max-w-xl py-12"><h1 className="h2 mb-6">متابعة الطلب</h1>
    <form onSubmit={go} className="grid gap-3"><input required inputMode="numeric" className="input" placeholder="رقم الطلب" value={n} onChange={e => setN(e.target.value)} /><input required dir="ltr" className="input text-start" placeholder="رقم الهاتف المستخدم في الطلب" value={ph} onChange={e => setPh(e.target.value)} /><button className="btn" disabled={busy}>بحث</button></form>
    {o === false && <p className="mt-6 text-crimson" role="alert">لا يوجد طلب بهذه البيانات.</p>}
    {o && <div className="card mt-6"><div className="text-lg font-bold">طلب رقم {o.number}</div>
      {o.status === 'cancelled' ? <p className="mt-3 font-semibold text-crimson">تم إلغاء الطلب</p> : <ol className="mt-4 flex">{ORDER.map((s, i) => <li key={s} className={`flex-1 border-t-4 pt-2 text-center text-sm ${i <= ORDER.indexOf(o.status) ? 'border-green font-bold text-green' : 'border-mist text-ink/40'}`}>{ST[s]}</li>)}</ol>}
      <ul className="mt-4 text-sm">{o.items.map((x, i) => <li key={i}>{x.name} — {x.size} / {x.color} × {x.qty}</li>)}</ul><div className="mt-3 font-bold">الإجمالي: {money(o.total)}</div></div>}
  </div>;
}
export default function Page() { return <Suspense><Track /></Suspense> }
