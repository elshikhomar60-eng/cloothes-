'use client';
import { useEffect, useState } from 'react'; import { supabase } from '@/lib/supabase'; import { useStore } from '@/lib/store'; import ProductCard from '@/components/ProductCard';
export default function Wishlist() {
  const { favs } = useStore(), [items, setItems] = useState([]);
  useEffect(() => { if (favs.length) supabase.from('products').select('*').in('id', favs).eq('visible', true).then(({ data }) => setItems(data || [])); else setItems([]) }, [favs]);
  return <div className="wrap py-10"><h1 className="h2 mb-6">المفضلة</h1>{!items.length ? <p className="py-16 text-center text-ink/60">لم تضف منتجات للمفضلة بعد.</p> : <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{items.map(p => <ProductCard key={p.id} p={p} />)}</div>}</div>;
}
