'use client';
import { useEffect } from 'react'; import { EN, RX } from '@/lib/i18n';
const tr = s => { const t = s.trim(); if (!t) return s; const lead = s.match(/^\s*/)[0], tail = s.match(/\s*$/)[0]; if (EN[t]) return lead + EN[t] + tail; let o = t; for (const [r, v] of RX) o = o.replace(r, v); return o === t ? s : lead + o + tail };
const ATTR = ['placeholder', 'aria-label', 'title'];
function walk(n) {
  if (n.nodeType === 3) { const v = tr(n.nodeValue); if (v !== n.nodeValue) n.nodeValue = v; return }
  if (n.nodeType !== 1 || ['SCRIPT', 'STYLE'].includes(n.tagName)) return;
  ATTR.forEach(a => { const v = n.getAttribute(a); if (v) { const x = tr(v); if (x !== v) n.setAttribute(a, x) } });
  n.childNodes.forEach(walk);
}
export default function Translator() {
  useEffect(() => {
    if (localStorage.getItem('lang') !== 'en') return;
    document.documentElement.lang = 'en'; document.documentElement.dir = 'ltr'; walk(document.body);
    const ob = new MutationObserver(ms => ms.forEach(m => { if (m.type === 'attributes') walk(m.target); else if (m.type === 'characterData') walk(m.target); else m.addedNodes.forEach(walk) }));
    ob.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTR });
    return () => ob.disconnect();
  }, []);
  return null;
}
